<!DOCTYPE html>
<html>
<head>
    <title>Student Marks Manager</title>
    <link rel="stylesheet" type="text/css" href="styles.css">

</head>
<body>
<div class="header">
    <h1>Student Marks Manager </h1>
    <div class ="headings">
        <a href="add.php"> Add Student </a> <br>
        <a href="show.php"> Show Students </a> <br>
        <a href="search.php"> Search Student </a> <br>
    </div>
</div>
<h2>List of all students</h2>

<?php
// Read data from data.txt and display student names
$data = file("data.txt");
$total_students = count($data);
echo "<p>Total number of students: $total_students</p>";
echo "<ul>";
foreach ($data as $line) {
    $fields = explode(",", $line);
    $student_id = $fields[0];
    $student_name = $fields[1];
    // Displaying student names as hyperlinks to search.php with student ID as parameter
    echo "<li><a href='search.php?id=$student_id'>$student_name</a></li>";
}
echo "</ul>";
?>
</body>
</html>
