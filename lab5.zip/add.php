<!DOCTYPE html>
<html>
<head>
    <title>Laboratory 5</title>
    <link rel="stylesheet" type="text/css" href="styles.css">

</head>
<body>

<div class="header">
<h1>Student Marks Manager </h1>
        <div class ="headings">
        <a href="add.php"> Add Student </a> <br>
        <a href="show.php"> Show Students </a> <br>
        <a href="search.php"> Search Student </a> <br>
        </div>
</div>


<div class="head">
<h1 id="headingone"> Enter the Student Marks </h1> 
</div>

    <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
 

        <div class="labels">
        <label for="name">Enter the name of the student</label>
        <input type="text" name="name" id="name"> <br>

        <label for="date">Date of Birth</label>
        <input type="date" id="date" name="date"> <br> 

        <label for="year">Year at University</label>
        <select id="year" name="year">
            <option value="1">1st Year</option>
            <option value="2">2nd Year</option>
            <option value="3">3rd Year</option>
            <option value="4">4th Year</option>
        </select> <br>

        <label for="firstcourse">Name of the First Course</label>
        <input type="text" id="firstcourse" name="firstcourse"> <br> 

        <label for="firstcoursemarks">First Course Marks</label>
        <input type="number" id="firstcoursemarks" name="firstcoursemarks"> <br>

        <label for="secondcourse">Name of the Second Course</label>
        <input type="text" id="secondcourse" name="secondcourse"> <br>

        <label for="secondcoursemarks">Second Course Marks</label>
        <input type="number" id="secondcoursemarks" name="secondcoursemarks"> <br>

        <label for="thirdcourse">Name of the Third Course</label>
        <input type="text" id="thirdcourse" name="thirdcourse"> <br>

        <label for="thirdcoursemarks">Third Course Marks</label>
        <input type="number" id="thirdcoursemarks" name="thirdcoursemarks"> <br>

        <label for="fourthcourse">Name of the Fourth Course</label>
        <input type="text" id="fourthcourse" name="fourthcourse"> <br>

        <label for="fourthcoursemarks">Fourth Course Marks</label>
        <input type="number" id="fourthcoursemarks" name="fourthcoursemarks"> <br>

        <button type="submit" id="submitbutton">Submit</button>
        </div>
    </form> 

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Check if all fields are filled
        if (!empty($_POST['name']) && !empty($_POST['date']) && !empty($_POST['year']) && !empty($_POST['firstcourse']) &&
            !empty($_POST['firstcoursemarks']) && !empty($_POST['secondcourse']) && !empty($_POST['secondcoursemarks']) && !empty($_POST['thirdcourse']) &&
            !empty($_POST['thirdcoursemarks']) && !empty($_POST['fourthcourse']) && !empty($_POST['fourthcoursemarks'])) {
            // Get the form data
            $name = $_POST['name'];
            $dateOfBirth = $_POST['date'];
            $yearAtUniversity = $_POST['year'];
            $firstCourse = $_POST['firstcourse'];
            $firstCourseMarks = $_POST['firstcoursemarks'];
            $secondCourse = $_POST['secondcourse'];
            $secondCourseMarks = $_POST['secondcoursemarks'];
            $thirdCourse = $_POST['thirdcourse'];
            $thirdCourseMarks = $_POST['thirdcoursemarks'];
            $fourthCourse = $_POST['fourthcourse'];
            $fourthCourseMarks = $_POST['fourthcoursemarks'];

            // Generate student ID using timestamp
            $student_id = time();

            // Prepare the data to be written
            $data = "$student_id,$name,$dateOfBirth,$yearAtUniversity,$firstCourse,$firstCourseMarks,$secondCourse,$secondCourseMarks,$thirdCourse,$thirdCourseMarks,$fourthCourse,$fourthCourseMarks\n";

            // Append data to the file
            $file = fopen("data.txt", "a");
            fwrite($file, $data);
            fclose($file);

            // Alert user
            echo "<script>alert('User has been added.');</script>";
        } else {
            // Alert user if any field is empty
            echo "<script>alert('Please fill in all fields.');</script>";
        }
    }
    ?>

</body>
</html>
