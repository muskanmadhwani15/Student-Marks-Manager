<?php
session_start();

$id = '';
$name = 'Not provided';
$date = 'Not provided';
$year = 'Not provided';
$firstCourse = 'Not provided';
$firstMarks = 'Not provided';
$secondCourse = 'Not provided';
$secondMarks = 'Not provided';
$thirdCourse = 'Not provided';
$thirdMarks = 'Not provided';
$fourthCourse = 'Not provided';
$fourthMarks = 'Not provided';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['id'])) {
    $id = filter_var($_POST['id'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);

    $data = file("data.txt");
    foreach ($data as $line) {
        $fields = explode(",", $line);
        if ($fields[0] == $id) {
            $name = $fields[1];
            $date = $fields[2];
            $year = $fields[3];
            $firstCourse = $fields[4];
            $firstMarks = $fields[5];
            $secondCourse = $fields[6];
            $secondMarks = $fields[7];
            $thirdCourse = $fields[8];
            $thirdMarks = $fields[9];
            $fourthCourse = $fields[10];
            $fourthMarks = $fields[11];
            break;
        }
    }
}

$currentYear = date("Y");
$dateOB = date("Y", strtotime($date));
$age = $currentYear - $dateOB;


$totalMarks = 0;

// Count the number of courses with marks
$numCourses = 0;

// Sum up the marks for each course
if ($firstMarks !== 'Not provided') {
    $totalMarks += $firstMarks;
    $numCourses++;
}
if ($secondMarks !== 'Not provided') {
    $totalMarks += $secondMarks;
    $numCourses++;
}
if ($thirdMarks !== 'Not provided') {
    $totalMarks += $thirdMarks;
    $numCourses++;
}
if ($fourthMarks !== 'Not provided') {
    $totalMarks += $fourthMarks;
    $numCourses++;
}

// Calculate the average if there are marks available
if ($numCourses > 0) {
    $average = $totalMarks / $numCourses;
} else {
    $average = 'Not provided';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Student</title>
    <link rel="stylesheet" href="searchh.css">
</head>
<body>
<div class="header">
<h1>Student Marks Manager </h1>
        <div class ="headings">
        <a href="add.php"> Add Student </a> <br>
        <a href="show.php"> Show Students </a> <br>
        <a href="search.php"> Search Student </a> <br>
        </div>
</div>
    <div class="container">
        <h1>Search Student</h1>
        <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
            <p>Enter the Student id: <input type="text" name="id" placeholder="Student id" required> <button type="submit">Submit</button></p>
        </form>
        <div class="student-info">
        <table>
    <tbody>
        <tr>
            <td><strong>Name:</strong></td>
            <td><?php echo $name; ?></td>
        </tr>
        <tr>
            <td><strong>Student ID:</strong></td>
            <td><?php echo $id; ?></td>
        </tr>
        <tr>
            <td><strong>Date of Birth:</strong></td>
            <td><?php echo $date; ?></td>
        </tr>
        <tr>
            <td><strong>Age:</strong></td>
            <td><?php echo $age; ?></td>
        </tr>
        <tr>
            <td><strong>Year at University:</strong></td>
            <td><?php echo $year; ?></td>
        </tr>
        <tr>
            <td colspan="2"><strong>Marks</strong></td>
        </tr>
        <tr>
            <td><?php echo $firstCourse; ?></td>
            <td><?php echo $firstMarks; ?></td>
        </tr>
        <tr>
            <td><?php echo $secondCourse; ?></td>
            <td><?php echo $secondMarks; ?></td>
        </tr>
        <tr>
            <td><?php echo $thirdCourse; ?></td>
            <td><?php echo $thirdMarks; ?></td>
        </tr>
        <tr>
            <td><?php echo $fourthCourse; ?></td>
            <td><?php echo $fourthMarks; ?></td>
        </tr>
        <tr>
            <td><strong>Final Percentage</strong></td>
            <td><?php echo $average; ?></td>
        </tr>
    </tbody>
</table>

        </div>
    </div>
</body>
</html>








